import Hero from "../component/Hero";

export default function Home() {
    return (
        <div>
            <section id="home">
        <Hero />
      </section>
        </div>
    )
}   