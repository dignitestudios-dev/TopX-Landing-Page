import Image from "next/image";
import Home from "./Home/page";
import PrivacyPolicy from "./PrivacyPolicy/page";
import Terms from "./Terms/page";

export default function page() {
  return (
    <div className="">
    <Home/>
  
    </div>
  );
}
