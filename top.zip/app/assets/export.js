import logo from "./topx-logo.png";
import bg from "./bg.png";
import mark from "./Mask.png";
export  {logo , bg, mark}
