(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_next_b7b356d5._.js",
  "static/chunks/app_6ebcb5f0._.js"
],
    source: "dynamic"
});
